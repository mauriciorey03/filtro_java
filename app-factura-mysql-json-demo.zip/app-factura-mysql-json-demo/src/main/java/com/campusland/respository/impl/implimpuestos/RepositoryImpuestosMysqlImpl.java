package com.campusland.respository.impl.implimpuestos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.campusland.respository.RepositoryImpuestos;
import com.campusland.respository.models.Cliente;
import com.campusland.respository.models.Impuestos;
import com.campusland.respository.models.Producto;
import com.campusland.utils.Formato;
import com.campusland.utils.conexionpersistencia.conexionbdmysql.ConexionBDMysql;


import java.sql.Statement;

public class RepositoryImpuestosMysqlImpl implements RepositoryImpuestos {

    private static final String SQL_GET_LIST_ImpuestosS = "SELECT f.numeroImpuestos, f.fecha, c.id, c.nombre, c.apellido, c.email, c.direccion, c.celular, c.documento FROM item_factura f JOIN cliente c ON c.id=f.cliente_id ORDER BY f.numeroImpuestos asc";
    private static final String SQL_GET_LIST_ITEMS_ImpuestosS = "SELECT i.id,i.cantidad,i.importe,p.codigo,p.nombre,p.descripcion,p.precioVenta,p.precioCompra  FROM item_Impuestos i join producto p on i.producto_codigo=p.codigo WHERE i.Impuestos_numeroImpuestos =?";
    private static final String INSERT_Impuestos = "INSERT INTO Impuestos (fecha, cliente_id) VALUES (?, ?)";
    private static final String INSERT_ITEM_Impuestos = "INSERT INTO item_Impuestos (Impuestos_numeroImpuestos, producto_codigo, cantidad, importe) VALUES (?, ?, ?, ?)";

    private Connection getConnection() throws SQLException {
        return ConexionBDMysql.getInstance();
    }

    @Override
    public List<Impuestos> listar() {
        List<Impuestos> listImpuestoss = new ArrayList<>();

        try (Connection conn = getConnection();
             PreparedStatement preparedStatement = conn.prepareStatement(SQL_GET_LIST_ImpuestosS);
             ResultSet rs = preparedStatement.executeQuery()) {

            while (rs.next()) {
                Impuestos Impuestos = creaImpuestos(rs);
                obtenerItemsImpuestos(conn,Impuestos);
                listImpuestoss.add(Impuestos);
            }

        } catch (SQLException e) {
            
                e.printStackTrace();
            
        }

       
        return listImpuestoss;
    }   

    private void obtenerItemsImpuestos(Connection connection,Impuestos Impuestos) throws SQLException {
        try (PreparedStatement preparedStatement = connection.prepareStatement(SQL_GET_LIST_ITEMS_ImpuestosS)) {
            preparedStatement.setInt(1, Impuestos.getNumeroImpuestos());
            try (ResultSet rs = preparedStatement.executeQuery()) {
                while (rs.next()) {
                    Impuestos.agregarItem(crearItems(rs));
                }
            }
        }
    }

    @Override
    public void crear(Impuestos Impuestos) throws ImpuestosExceptionInsertDataBase {
        Connection conn=null;
        try {
            conn = getConnection();
            conn.setAutoCommit(false);

            try (PreparedStatement psImpuestos = conn.prepareStatement(INSERT_Impuestos,
                    Statement.RETURN_GENERATED_KEYS)) {
                psImpuestos.setDate(1, Formato.convertirLocalDateTimeSqlDate(Impuestos.getFecha()));
                psImpuestos.setInt(2, Impuestos.getCliente().getId());
                psImpuestos.executeUpdate();

                try (ResultSet generatedKeys = psImpuestos.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        Impuestos.setNumeroImpuestos(generatedKeys.getInt(1));
                    } else {
                        throw new SQLException("No se pudo obtener el valor autoincremental para numeroImpuestos");
                    }
                }
            }

            try (PreparedStatement psItem = conn.prepareStatement(INSERT_ITEM_Impuestos)) {
                for (ItemImpuestos item : Impuestos.getItems()) {
                    psItem.setInt(1, Impuestos.getNumeroImpuestos());
                    psItem.setInt(2, item.getProducto().getCodigo());
                    psItem.setInt(3, item.getCantidad());
                    psItem.setDouble(4, item.getImporte());
                    psItem.addBatch();
                }
                psItem.executeBatch();
            }

            conn.commit();
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException rollbackException) {
                    rollbackException.printStackTrace();                    
                }
            }
            e.printStackTrace();
            throw new ImpuestosExceptionInsertDataBase("No se pudo hacer el insert en la base de datos de Impuestos");
        }finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException closeException) {
                    closeException.printStackTrace();                    
                }
            }
        }
    }

   

    private Impuestos creaImpuestos(ResultSet rs) throws SQLException {
        final int clienteId = rs.getInt("id");
        final String documento = rs.getString("documento");
        final String nombre = rs.getString("nombre");
        final String apellido = rs.getString("apellido");
        final String email = rs.getString("email");
        final String direccion = rs.getString("direccion");
        final String celular = rs.getString("celular");
        final Cliente cliente = new Cliente(clienteId, documento, nombre, apellido, email, direccion, celular);
        final int numeroImpuestos = rs.getInt("numeroImpuestos");
        final LocalDateTime fecha = Formato.convertirTimestampFecha(rs.getTimestamp("fecha"));
        return new Impuestos(numeroImpuestos, fecha, cliente);

    }

    private ItemImpuestos crearItems(ResultSet rs) throws SQLException {
        final int codigo = rs.getInt("codigo");
        final String nombre = rs.getString("nombre");
        final String descripcion = rs.getString("descripcion");
        final double precioVenta = rs.getDouble("precioVenta");
        final double precioCompra = rs.getDouble("precioCompra");
        final Producto producto = new Producto(codigo, nombre, descripcion, precioVenta, precioCompra);
        return new ItemImpuestos(rs.getInt("cantidad"), producto);

    }

}
