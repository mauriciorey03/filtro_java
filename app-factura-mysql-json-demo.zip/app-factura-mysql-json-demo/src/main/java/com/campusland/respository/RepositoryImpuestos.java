package com.campusland.respository;

import java.util.List;

import com.campusland.exceptiones.impuestosexceptions.ImpuestosExceptionInsertDataBase;
import com.campusland.respository.models.Impuestos;

public interface RepositoryImpuestos {

    List<Impuestos> listar();

    void crear(Impuestos impuestos)throws ImpuestosExceptionInsertDataBase;
    
}
