package com.campusland.respository.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Impuestos {

    private int cantidad;
    private Producto producto;

    public double getAno(){
        return this.cantidad*this.producto.getAno();
    }



    @Override
    public String toString() {
        return "Impuestos [año=" + cantidad + ", producto=" + producto.toString() + "]";
    }
    
}
