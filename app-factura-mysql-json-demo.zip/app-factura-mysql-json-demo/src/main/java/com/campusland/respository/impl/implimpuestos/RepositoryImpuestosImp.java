package com.campusland.respository.impl.implimpuestos;

import java.util.List;

import com.campusland.exceptiones.impuestosexceptions.ImpuestosExceptionInsertDataBase;
import com.campusland.respository.RepositoryImpuestos;
import com.campusland.respository.models.Impuestos;
import com.campusland.utils.conexionpersistencia.conexiondblist.ConexionBDList;

public class RepositoryImpuestosImp implements RepositoryImpuestos {

    ConexionBDList conexion = ConexionBDList.getConexion();

   
    @Override
    public List<Impuestos> listar() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'listar'");
    }


    @Override
    public void crear(Impuestos impuestos) throws ImpuestosExceptionInsertDataBase {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'crear'");
    }

}
