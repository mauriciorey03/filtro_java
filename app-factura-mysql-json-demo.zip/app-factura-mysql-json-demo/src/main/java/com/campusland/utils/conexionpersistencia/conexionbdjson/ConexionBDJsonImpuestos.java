package com.campusland.utils.conexionpersistencia.conexionbdjson;

import com.campusland.respository.models.Factura;

public class ConexionBDJsonImpuestos extends ConexionBDJsonBase<Factura>  {

    private static ConexionBDJsonImpuestos conexionProductos;

    private ConexionBDJsonImpuestos() {
        super("Impuestos.json");
    }

    public static ConexionBDJsonImpuestos getConexion() {
        if (conexionProductos != null) {
            return conexionProductos;
        } else {
            conexionProductos = new ConexionBDJsonImpuestos();
            return conexionProductos;
        }
    }
    
}
