package com.campusland.exceptiones.impuestosexceptions;

public class ImpuestosExceptionInsertDataBase extends ImpuestosException {

    public ImpuestosExceptionInsertDataBase(String mensaje) {
        super(mensaje);
        
    }
    
}
