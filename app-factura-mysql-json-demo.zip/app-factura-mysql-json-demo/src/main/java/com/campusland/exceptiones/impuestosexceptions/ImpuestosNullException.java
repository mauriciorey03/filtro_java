package com.campusland.exceptiones.impuestosexceptions;

public class ImpuestosNullException extends ImpuestosException {

    public ImpuestosNullException(String mensaje) {
        super(mensaje);        
    }
    
}
