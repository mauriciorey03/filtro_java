package com.campusland.exceptiones.impuestosexceptions;

public class ImpuestosException extends Exception{

    public ImpuestosException(String mensaje) {
        super(mensaje);
    }
    
}
